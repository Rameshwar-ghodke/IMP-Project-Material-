<html>
<head>
  <title>Switch CSS Class Using jQuery</title>
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <style>
  .image-content{width: 200px;border: #D2CCCC 1px solid;padding: 5px 40px;height: 280px;border-radius: 4px;box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.25);}
	#switch {padding: 10px 20px;margin: 15px 0px;border-radius: 4px;border: 0;background: #7A7B7B;color: #FFF;}
  .small-icon{width:50px;}
  .large-icon{width:100px;}
  .extra-large-icon{width:200px;}
  </style>
  <script>
  $(document).ready(function() {
    $("#switch").click(function(){
      $(".small-icon").switchClass("small-icon", "large-icon", 500);
      $(".large-icon").switchClass("large-icon", "extra-large-icon", 500);
	  $(".extra-large-icon").switchClass("extra-large-icon", "small-icon", 500);
    });
  });
  </script>
</head>
<body>
<div class="image-content">
<button id="switch">Switch Class</button> 
	<div  class="small-icon">
	  <img src="image.png" width="100%" />
	</div> 
	</div> 
</div>
</body>
</html>