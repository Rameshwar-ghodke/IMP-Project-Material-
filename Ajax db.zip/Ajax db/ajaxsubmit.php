<?php
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server..
$db = mysql_select_db("mydatabase", $connection); // Selecting Database

//Fetching Values from URL
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$contact=$_POST['contact'];

//Insert query
$query = mysql_query("insert into ajaxdb(name, email, password, contact) values ('$name', '$email', '$password','$contact')");
echo "Form Submitted Succesfully";

mysql_close($connection); // Connection Closed
?>