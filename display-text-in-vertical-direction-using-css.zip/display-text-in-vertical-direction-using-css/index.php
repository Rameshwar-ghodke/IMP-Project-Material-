<html>
<head>
  <title>Display Text in Vertical Direction using CSS</title>
  <style>
		body{width:610px;}
	  
		#vertical-orientation {
			float: left;
			transform: rotate(90deg);
			transform-origin: left top 0;
			margin-left: 50px;
			padding: 10px;
			background-color: rgba(37, 34, 34, 0.3);
			opacity: 0.9;
			font-size: 1.8em;
			color: #FFF;
			text-transform: uppercase;
		}
		#image-golf {
			background:url("golf.jpg");
			width: 600px;
			height: 350px;
		}
  </style>
</head>
<body> 

<div id="image-golf">
<div id="vertical-orientation">Vertical Direction</div></div>
</body>
</html>