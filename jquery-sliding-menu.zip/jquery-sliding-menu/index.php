<style>
.menu-list {
    background: #ba63c6;
    position: absolute;
    top: 0;
    left: -200px;
    height: 100%;
    transition: 0.7s;
    width: 200px;
	opacity:0.9;
}
#expand-menu {
	display:inline-block;
	cursor:pointer;
}
#close {
	margin:10px;
	float:right;
	display:inline-block;
	cursor:pointer;	
	color:#FFF;
    font-size: 16px;
    opacity: 0.5;
}
.menu-list ul{
    list-style: none;
    margin: 0px;
    padding: 0px;
    clear: both;
}

.menu-links {
	padding: 10px;
	background:#c781d0;
	margin-bottom:1px;
	cursor:pointer;		
	color: #FFF;
}
.menu-link-target{
    position: absolute;
    left: 0px;
    transition: 0.7s;
	padding:20px;
	width:400px;
	height:300px;
}
.menu-link-target p{
	margin-bottom:60px;
}
</style>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<div>
<div class="menu-list">
<div id="close">X</div>
<ul>
    <li class="menu-links" id ="about">About</li>
	<li class="menu-links" id ="photos">Photos</li>
    <li class="menu-links" id ="terms">Terms and Conditions</li>
    <li class="menu-links" id ="contact">Contact</a></li>

</ul>
</div>
<div class="menu-link-target">
<div id="expand-menu"><img src="menu.png" width="24px"/></div>
<h4 id="about-content">About</h4>
<p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
<h4 id="photos-content">Photos</h4>
<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages. And web page editors now use this as their default model text, and  will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose.</p>
<h4 id="terms-content">Terms and Conditions</h4>
<p>There are many variations of passages of available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the generators on the Internet tend to repeat predefined chunks as necessary. Making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures.</p>
<h4 id="contact-content">Contact</h4>
<p>The standard chunk of this used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.  Comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance.</p>
</div>
</div>
<script>
	$("#expand-menu").on('click',function(){
		$(".menu-list").css( {"left": 0});
		$(".menu-link-target").css( {"left": 200});
		$("#expand-menu").hide();
	});
	$("#close").on('click',function(){
		$(".menu-list").css({"left": "-"+ $(".menu-list").width()});
		$(".menu-link-target").css( {"left": 0});
		$("#expand-menu").show();
	});
	$('.menu-links').click(function() { 
		var target = $(this).attr('id');
		$('html, body').animate({scrollTop: $('#'+target+'-content').offset().top}, 1000);
	});
</script>