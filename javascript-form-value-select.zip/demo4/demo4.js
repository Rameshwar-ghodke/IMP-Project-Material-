function set_matching_word(selectObj, txtObj) {
  var letter = txtObj.value;
  
  for(var i = 0; i < selectObj.length; i++) {
 
     if(selectObj.options[i].value == letter)
     	selectObj.selectedIndex = i;
   
  }

}
