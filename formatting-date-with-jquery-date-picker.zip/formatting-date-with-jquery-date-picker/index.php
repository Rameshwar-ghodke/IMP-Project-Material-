<html>
<head>
  <title>Formatting Date With jQuery Date Picker</title>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <style>
		body{width:610px;}
	  
		#frm-date-format {
			padding: 20px 40px;
			background: #82ade4;
			color: #FFF;
			font-size: 1.2em;
		}
		
		.frm-input-row {
			margin-bottom: 20px;
		}
		
		.frm-input {
			padding: 10px;
			width: 250px;
			font-size: 0.8em;
		}
  </style>
  <script>
  $(document).ready(function() {
    $( "#datepicker" ).datepicker();
  });
  function setDateFormat(date_format) {
	  $( "#datepicker" ).datepicker( "option", "dateFormat", date_format );
  }
  </script>
</head>
<body> 
<div id="frm-date-format">
	<div class="frm-input-row">
		<div class="frm-label">Select Date:</div>
		<div><input type="text" id="datepicker" size="30" class="frm-input"></div> 
	</div>
	<div class="frm-input-row">
		<div>Formats:</div>
		<div>
			<select id="date-format" onchange="setDateFormat(this.value);" class="frm-input">
				<option value="mm/dd/yy">mm/dd/yy</option>
				<option value="dd/mm/yy">dd/mm/yy</option>
				<option value="yy-mm-dd">yy-mm-dd</option>
				<option value="M d, y">M d, y</option>
			</select>
		</div>
	</div>
</div>
</body>
</html>